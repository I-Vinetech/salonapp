class WalkThroughModel {
  String? title;
  String? subTitle;
  String? img;

  WalkThroughModel({this.title, this.subTitle, this.img});
}